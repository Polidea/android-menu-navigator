import junit.framework.TestCase;

/**
 * Empty test case.
 *
 * @author potiuk
 *
 */
public class EmptyTest extends TestCase {
    public void testEmpty() {
        // do nothing
    }
}
